------------------------------------------------------------
-- 1. View: активні (не видалені) пацієнти
------------------------------------------------------------
CREATE OR REPLACE VIEW "v_active_patients" AS
SELECT
    p.id,
    p.mrn,
    p.full_name,
    p.birth_date,
    p.phone,
    p.address,
    p.emergency_contact
FROM "patients" p
WHERE p.deleted_at IS NULL;

------------------------------------------------------------
-- 2. View: поточні стаціонарні пацієнти
------------------------------------------------------------
CREATE OR REPLACE VIEW "v_current_inpatients" AS
SELECT
    a.id              AS admission_id,
    p.id              AS patient_id,
    p.full_name       AS patient_name,
    a.admitted_at,
    a.status,
    b.id              AS bed_id,
    b.bed_no,
    r.code            AS room_code,
    d.name            AS department_name
FROM "admissions" a
JOIN "patients" p      ON p.id = a.patient_id
LEFT JOIN "beds" b     ON b.id = a.bed_id
LEFT JOIN "rooms" r    ON r.id = b.room_id
LEFT JOIN "departments" d ON d.id = r.department_id
WHERE a.status = 'admitted';

------------------------------------------------------------
-- 3. View: розклад лікарів
------------------------------------------------------------
CREATE OR REPLACE VIEW "v_doctor_schedule" AS
SELECT
    a.id              AS appointment_id,
    a.starts_at,
    a.ends_at,
    a.status,
    d.id              AS doctor_id,
    u.full_name       AS doctor_name,
    dep.name          AS department_name,
    p.full_name       AS patient_name
FROM "appointments" a
JOIN "doctors" d        ON d.id = a.doctor_id
LEFT JOIN "users" u     ON u.id = d.user_id
JOIN "patients" p       ON p.id = a.patient_id
LEFT JOIN "departments" dep ON dep.id = d.department_id
WHERE a.deleted_at IS NULL;