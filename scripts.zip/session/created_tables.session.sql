CREATE TABLE "users" (
  "id" uuid PRIMARY KEY,
  "email" text NOT NULL,
  "password_hash" text NOT NULL,
  "full_name" text,
  "created_at" timestamptz NOT NULL,
  "created_by" uuid,
  "updated_at" timestamptz,
  "updated_by" uuid,
  "deleted_at" timestamptz,
  "deleted_by" uuid
);

CREATE TABLE "roles" (
  "id" uuid PRIMARY KEY,
  "code" text NOT NULL,
  "name" text NOT NULL
);

CREATE TABLE "user_roles" (
  "user_id" uuid NOT NULL,
  "role_id" uuid NOT NULL,
  PRIMARY KEY ("user_id", "role_id")
);

CREATE TABLE "patients" (
  "id" uuid PRIMARY KEY,
  "mrn" text NOT NULL,
  "full_name" text NOT NULL,
  "birth_date" date,
  "phone" text,
  "address" text,
  "emergency_contact" text,
  "created_at" timestamptz NOT NULL,
  "created_by" uuid,
  "updated_at" timestamptz,
  "updated_by" uuid,
  "deleted_at" timestamptz,
  "deleted_by" uuid
);

CREATE TABLE "departments" (
  "id" uuid PRIMARY KEY,
  "name" text NOT NULL,
  "created_at" timestamptz NOT NULL,
  "created_by" uuid,
  "updated_at" timestamptz,
  "updated_by" uuid,
  "deleted_at" timestamptz,
  "deleted_by" uuid
);

CREATE TABLE "doctors" (
  "id" uuid PRIMARY KEY,
  "user_id" uuid,
  "department_id" uuid,
  "license_no" text NOT NULL,
  "speciality" text,
  "created_at" timestamptz NOT NULL,
  "created_by" uuid,
  "updated_at" timestamptz,
  "updated_by" uuid,
  "deleted_at" timestamptz,
  "deleted_by" uuid
);

CREATE TABLE "rooms" (
  "id" uuid PRIMARY KEY,
  "department_id" uuid,
  "code" text NOT NULL,
  "created_at" timestamptz NOT NULL,
  "created_by" uuid,
  "updated_at" timestamptz,
  "updated_by" uuid,
  "deleted_at" timestamptz,
  "deleted_by" uuid
);

CREATE TABLE "beds" (
  "id" uuid PRIMARY KEY,
  "room_id" uuid NOT NULL,
  "bed_no" text NOT NULL,
  "is_occupied" boolean NOT NULL DEFAULT false,
  "created_at" timestamptz NOT NULL,
  "created_by" uuid,
  "updated_at" timestamptz,
  "updated_by" uuid,
  "deleted_at" timestamptz,
  "deleted_by" uuid
);

CREATE TABLE "appointments" (
  "id" uuid PRIMARY KEY,
  "patient_id" uuid NOT NULL,
  "doctor_id" uuid NOT NULL,
  "starts_at" timestamptz NOT NULL,
  "ends_at" timestamptz NOT NULL,
  "status" text NOT NULL DEFAULT 'scheduled',
  "note" text,
  "created_at" timestamptz NOT NULL,
  "created_by" uuid,
  "updated_at" timestamptz,
  "updated_by" uuid,
  "deleted_at" timestamptz,
  "deleted_by" uuid
);

CREATE TABLE "admissions" (
  "id" uuid PRIMARY KEY,
  "patient_id" uuid NOT NULL,
  "doctor_id" uuid NOT NULL,
  "bed_id" uuid,
  "admitted_at" timestamptz NOT NULL,
  "discharged_at" timestamptz,
  "status" text NOT NULL DEFAULT 'admitted',
  "created_at" timestamptz NOT NULL,
  "created_by" uuid,
  "updated_at" timestamptz,
  "updated_by" uuid
);

CREATE TABLE "diagnoses" (
  "id" uuid PRIMARY KEY,
  "patient_id" uuid NOT NULL,
  "doctor_id" uuid NOT NULL,
  "admission_id" uuid,
  "code" text NOT NULL,
  "description" text,
  "diagnosed_at" timestamptz NOT NULL,
  "created_at" timestamptz NOT NULL,
  "created_by" uuid,
  "updated_at" timestamptz,
  "updated_by" uuid,
  "deleted_at" timestamptz,
  "deleted_by" uuid
);

CREATE TABLE "procedures" (
  "id" uuid PRIMARY KEY,
  "patient_id" uuid NOT NULL,
  "doctor_id" uuid NOT NULL,
  "admission_id" uuid,
  "name" text NOT NULL,
  "cost" numeric(12,2) NOT NULL,
  "performed_at" timestamptz NOT NULL,
  "created_at" timestamptz NOT NULL,
  "created_by" uuid,
  "updated_at" timestamptz,
  "updated_by" uuid,
  "deleted_at" timestamptz,
  "deleted_by" uuid
);

CREATE TABLE "medications" (
  "id" uuid PRIMARY KEY,
  "name" text NOT NULL,
  "form" text,
  "strength" text,
  "created_at" timestamptz NOT NULL,
  "created_by" uuid,
  "updated_at" timestamptz,
  "updated_by" uuid,
  "deleted_at" timestamptz,
  "deleted_by" uuid
);

CREATE TABLE "prescriptions" (
  "id" uuid PRIMARY KEY,
  "patient_id" uuid NOT NULL,
  "doctor_id" uuid NOT NULL,
  "admission_id" uuid,
  "medication_id" uuid NOT NULL,
  "dose" text,
  "frequency" text,
  "days" int,
  "start_at" date,
  "created_at" timestamptz NOT NULL,
  "created_by" uuid,
  "updated_at" timestamptz,
  "updated_by" uuid,
  "deleted_at" timestamptz,
  "deleted_by" uuid
);

CREATE TABLE "lab_tests" (
  "id" uuid PRIMARY KEY,
  "code" text NOT NULL,
  "name" text NOT NULL,
  "default_price" numeric(12,2) NOT NULL,
  "created_at" timestamptz NOT NULL,
  "created_by" uuid,
  "updated_at" timestamptz,
  "updated_by" uuid,
  "deleted_at" timestamptz,
  "deleted_by" uuid
);

CREATE TABLE "lab_orders" (
  "id" uuid PRIMARY KEY,
  "patient_id" uuid NOT NULL,
  "doctor_id" uuid NOT NULL,
  "admission_id" uuid,
  "lab_test_id" uuid NOT NULL,
  "ordered_at" timestamptz NOT NULL,
  "result" text,
  "price" numeric(12,2) NOT NULL,
  "created_at" timestamptz NOT NULL,
  "created_by" uuid,
  "updated_at" timestamptz,
  "updated_by" uuid,
  "deleted_at" timestamptz,
  "deleted_by" uuid
);

CREATE TABLE "invoices" (
  "id" uuid PRIMARY KEY,
  "patient_id" uuid NOT NULL,
  "issued_at" timestamptz NOT NULL,
  "status" text NOT NULL DEFAULT 'open',
  "created_at" timestamptz NOT NULL,
  "created_by" uuid,
  "updated_at" timestamptz,
  "updated_by" uuid
);

CREATE TABLE "invoice_items" (
  "id" uuid PRIMARY KEY,
  "invoice_id" uuid NOT NULL,
  "item_type" text NOT NULL,
  "ref_id" uuid,
  "description" text NOT NULL,
  "qty" numeric(12,2) NOT NULL DEFAULT 1,
  "unit_price" numeric(12,2) NOT NULL
);

CREATE TABLE "payments" (
  "id" uuid PRIMARY KEY,
  "patient_id" uuid NOT NULL,
  "invoice_id" uuid NOT NULL,
  "paid_at" timestamptz NOT NULL,
  "amount" numeric(12,2) NOT NULL,
  "method" text NOT NULL
);

CREATE INDEX "ux_users_email" ON "users" ("email");

CREATE UNIQUE INDEX "ux_roles_code" ON "roles" ("code");

CREATE INDEX "ux_patients_mrn" ON "patients" ("mrn");

CREATE INDEX "ux_doctors_license" ON "doctors" ("license_no");

CREATE UNIQUE INDEX "ux_beds_room_bedno" ON "beds" ("room_id", "bed_no");

CREATE INDEX "ix_appt_doctor_time" ON "appointments" ("doctor_id", "starts_at");

CREATE INDEX "ix_appt_patient_time" ON "appointments" ("patient_id", "starts_at");

CREATE UNIQUE INDEX "ux_lab_tests_code" ON "lab_tests" ("code");

COMMENT ON COLUMN "users"."email" IS 'unique among active';

COMMENT ON COLUMN "patients"."mrn" IS 'medical record number';

ALTER TABLE "user_roles" ADD FOREIGN KEY ("user_id") REFERENCES "users" ("id");

ALTER TABLE "user_roles" ADD FOREIGN KEY ("role_id") REFERENCES "roles" ("id");

ALTER TABLE "doctors" ADD FOREIGN KEY ("user_id") REFERENCES "users" ("id");

ALTER TABLE "doctors" ADD FOREIGN KEY ("department_id") REFERENCES "departments" ("id");

ALTER TABLE "rooms" ADD FOREIGN KEY ("department_id") REFERENCES "departments" ("id");

ALTER TABLE "beds" ADD FOREIGN KEY ("room_id") REFERENCES "rooms" ("id");

ALTER TABLE "appointments" ADD FOREIGN KEY ("patient_id") REFERENCES "patients" ("id");

ALTER TABLE "appointments" ADD FOREIGN KEY ("doctor_id") REFERENCES "doctors" ("id");

ALTER TABLE "admissions" ADD FOREIGN KEY ("patient_id") REFERENCES "patients" ("id");

ALTER TABLE "admissions" ADD FOREIGN KEY ("doctor_id") REFERENCES "doctors" ("id");

ALTER TABLE "admissions" ADD FOREIGN KEY ("bed_id") REFERENCES "beds" ("id");

ALTER TABLE "diagnoses" ADD FOREIGN KEY ("patient_id") REFERENCES "patients" ("id");

ALTER TABLE "diagnoses" ADD FOREIGN KEY ("doctor_id") REFERENCES "doctors" ("id");

ALTER TABLE "diagnoses" ADD FOREIGN KEY ("admission_id") REFERENCES "admissions" ("id");

ALTER TABLE "procedures" ADD FOREIGN KEY ("patient_id") REFERENCES "patients" ("id");

ALTER TABLE "procedures" ADD FOREIGN KEY ("doctor_id") REFERENCES "doctors" ("id");

ALTER TABLE "procedures" ADD FOREIGN KEY ("admission_id") REFERENCES "admissions" ("id");

ALTER TABLE "prescriptions" ADD FOREIGN KEY ("patient_id") REFERENCES "patients" ("id");

ALTER TABLE "prescriptions" ADD FOREIGN KEY ("doctor_id") REFERENCES "doctors" ("id");

ALTER TABLE "prescriptions" ADD FOREIGN KEY ("admission_id") REFERENCES "admissions" ("id");

ALTER TABLE "prescriptions" ADD FOREIGN KEY ("medication_id") REFERENCES "medications" ("id");

ALTER TABLE "lab_orders" ADD FOREIGN KEY ("patient_id") REFERENCES "patients" ("id");

ALTER TABLE "lab_orders" ADD FOREIGN KEY ("doctor_id") REFERENCES "doctors" ("id");

ALTER TABLE "lab_orders" ADD FOREIGN KEY ("admission_id") REFERENCES "admissions" ("id");

ALTER TABLE "lab_orders" ADD FOREIGN KEY ("lab_test_id") REFERENCES "lab_tests" ("id");

ALTER TABLE "invoices" ADD FOREIGN KEY ("patient_id") REFERENCES "patients" ("id");

ALTER TABLE "invoice_items" ADD FOREIGN KEY ("invoice_id") REFERENCES "invoices" ("id");

ALTER TABLE "payments" ADD FOREIGN KEY ("patient_id") REFERENCES "patients" ("id");

ALTER TABLE "payments" ADD FOREIGN KEY ("invoice_id") REFERENCES "invoices" ("id");
