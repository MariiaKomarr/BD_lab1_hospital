------------------------------------------------------------
-- 1. Функція: підрахунок суми рахунку
------------------------------------------------------------
CREATE OR REPLACE FUNCTION calc_invoice_total(p_invoice_id uuid)
RETURNS numeric(12,2)
LANGUAGE sql
AS $$
    SELECT COALESCE(SUM(ii.qty * ii.unit_price), 0.00)
    FROM "invoice_items" ii
    WHERE ii.invoice_id = p_invoice_id;
$$;

------------------------------------------------------------
-- 2. Функція: баланс пацієнта (рахунки - оплати)
------------------------------------------------------------
CREATE OR REPLACE FUNCTION get_patient_balance(p_patient_id uuid)
RETURNS numeric(12,2)
LANGUAGE plpgsql
AS $$
DECLARE
    v_invoices numeric(12,2);
    v_payments numeric(12,2);
BEGIN
    SELECT COALESCE(SUM(ii.qty * ii.unit_price), 0)
    INTO v_invoices
    FROM "invoices" i
    JOIN "invoice_items" ii ON ii.invoice_id = i.id
    WHERE i.patient_id = p_patient_id;

    SELECT COALESCE(SUM(p.amount), 0)
    INTO v_payments
    FROM "payments" p
    WHERE p.patient_id = p_patient_id;

    RETURN v_invoices - v_payments;
END;
$$;