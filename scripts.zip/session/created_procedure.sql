------------------------------------------------------------
-- 1. Процедура: виписати пацієнта зі стаціонару
--    + звільнити ліжко
------------------------------------------------------------
CREATE OR REPLACE PROCEDURE discharge_patient(
    p_admission_id uuid,
    p_user_id      uuid,
    p_discharged_at timestamptz DEFAULT now()
)
LANGUAGE plpgsql
AS $$
DECLARE
    v_bed_id uuid;
BEGIN
    UPDATE "admissions" a
    SET discharged_at = COALESCE(p_discharged_at, now()),
        status        = 'discharged',
        updated_at    = now(),
        updated_by    = p_user_id
    WHERE a.id = p_admission_id
    RETURNING a.bed_id INTO v_bed_id;

    IF v_bed_id IS NOT NULL THEN
        UPDATE "beds" b
        SET is_occupied = FALSE,
            updated_at  = now(),
            updated_by  = p_user_id
        WHERE b.id = v_bed_id;
    END IF;
END;
$$;

------------------------------------------------------------
-- 2. Процедура: soft delete пацієнта
--    + відмінити майбутні прийоми
------------------------------------------------------------
CREATE OR REPLACE PROCEDURE soft_delete_patient(
    p_patient_id uuid,
    p_user_id    uuid
)
LANGUAGE plpgsql
AS $$
BEGIN
    -- Позначити пацієнта як видаленого
    UPDATE "patients" p
    SET deleted_at = now(),
        deleted_by = p_user_id
    WHERE p.id = p_patient_id
      AND p.deleted_at IS NULL;

    -- Відмінити майбутні візити
    UPDATE "appointments" a
    SET status     = 'cancelled',
        deleted_at = now(),
        deleted_by = p_user_id
    WHERE a.patient_id = p_patient_id
      AND a.deleted_at IS NULL
      AND a.starts_at > now();
END;
$$;