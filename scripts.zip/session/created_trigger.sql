------------------------------------------------------------
-- 1. Функція-тригер: автоматичні created_at / updated_at
------------------------------------------------------------
CREATE OR REPLACE FUNCTION set_audit_fields()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        IF NEW.created_at IS NULL THEN
            NEW.created_at := now();
        END IF;
    ELSIF TG_OP = 'UPDATE' THEN
        NEW.updated_at := now();
    END IF;
    RETURN NEW;
END;
$$;

------------------------------------------------------------
-- 2. Тригер на таблицю patients
------------------------------------------------------------
CREATE TRIGGER trg_patients_audit
BEFORE INSERT OR UPDATE ON "patients"
FOR EACH ROW
EXECUTE FUNCTION set_audit_fields();

------------------------------------------------------------
-- 3. Тригер на таблицю doctors
------------------------------------------------------------
CREATE TRIGGER trg_doctors_audit
BEFORE INSERT OR UPDATE ON "doctors"
FOR EACH ROW
EXECUTE FUNCTION set_audit_fields();

------------------------------------------------------------
-- 4. Тригер на таблицю admissions
------------------------------------------------------------
CREATE TRIGGER trg_admissions_audit
BEFORE INSERT OR UPDATE ON "admissions"
FOR EACH ROW
EXECUTE FUNCTION set_audit_fields();